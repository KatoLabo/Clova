(function(){
  print('hello, world!');
}());